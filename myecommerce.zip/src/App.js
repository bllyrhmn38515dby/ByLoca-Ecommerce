import React, { useState } from 'react';
import Product from './components/Product';
import Cart from './components/Cart';

const App = () => {
  const [cart, setCart] = useState([]);
  const [isCheckedOut, setIsCheckedOut] = useState(false);
  const products = [
    { name: 'Product 1', price: 10 },
    { name: 'Product 2', price: 20 },
    { name: 'Product 3', price: 30 },
  ];

  const addToCart = (product) => {
    setCart([...cart, product]);
  };

  const removeFromCart = (index) => {
    const newCart = cart.filter((_, i) => i !== index);
    setCart(newCart);
  };

  const handleCheckout = () => {
    setIsCheckedOut(true);
    setCart([]); // Kosongkan keranjang setelah checkout
  };

  return (
    <div className="container mx-auto p-6">
      <h1 className="text-3xl font-bold text-center mb-6 text-blue-600">Simple E-commerce</h1>
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {products.map((product, index) => (
          <Product key={index} product={product} addToCart={addToCart} />
        ))}
      </div>
      <div className="mt-8">
        <Cart cartItems={cart} removeFromCart={removeFromCart} />
        {cart.length > 0 && !isCheckedOut && (
          <button 
            className="mt-4 bg-green-500 text-white px-4 py-2 rounded hover:bg-green-600"
            onClick={handleCheckout}
          >
            Checkout
          </button>
        )}
        {isCheckedOut && (
          <div className="mt-4 text-green-600 font-bold">Thank you for your purchase!</div>
        )}
      </div>
    </div>
  );
};

export default App;
