import React from 'react';

const LazyComponent = () => {
  return (
    <div>
      <h2>This is a lazily loaded component!</h2>
    </div>
  );
};

export default LazyComponent;
