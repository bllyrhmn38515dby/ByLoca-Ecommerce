import React from 'react';

const Cart = ({ cartItems, removeFromCart }) => {
  const totalPrice = cartItems.reduce((total, item) => total + item.price, 0);

  return (
    <div className="border rounded-lg shadow-lg p-4">
      <h2 className="text-lg font-semibold">Cart</h2>
      {cartItems.length === 0 ? (
        <p className="text-gray-500">Your cart is empty</p>
      ) : (
        <>
          {cartItems.map((item, index) => (
            <div key={index} className="flex justify-between py-1 border-b">
              <span>{item.name}</span>
              <span>${item.price}</span>
              <button 
                className="text-red-500 hover:text-red-700"
                onClick={() => removeFromCart(index)}
              >
                Remove
              </button>
            </div>
          ))}
          <div className="mt-2 font-bold">Total: ${totalPrice}</div>
        </>
      )}
    </div>
  );
};

export default Cart;
