import React from 'react';

const Product = ({ product, addToCart }) => {
  return (
    <div className="border rounded-lg shadow-lg p-4 transition-transform transform hover:scale-105">
      <h2 className="text-lg font-semibold text-gray-800">{product.name}</h2>
      <p className="text-gray-600">${product.price}</p>
      <button 
        className="mt-2 bg-blue-500 text-white px-4 py-2 rounded hover:bg-blue-600 transition"
        onClick={() => addToCart(product)}
      >
        Add to Cart
      </button>
    </div>
  );
};

export default Product;
